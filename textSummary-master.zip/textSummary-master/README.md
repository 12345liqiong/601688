[![Build Status](https://travis-ci.org/zkwi/textSummary.svg?branch=master)](https://travis-ci.org/zkwi/textSummary)
# textSummary
网页内容摘要智能抽取技术实现 [演示地址](http://textsummary.herokuapp.com/)

